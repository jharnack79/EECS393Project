﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetThiqqq.Services
{
    public class UserCalendar
    {
        public int Id { get; set; }

        public int UserAccountId { get; set; }

        public string Month { get; set; }
    }
}
