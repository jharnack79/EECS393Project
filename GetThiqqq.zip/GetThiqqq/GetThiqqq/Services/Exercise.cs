﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetThiqqq.Services
{
    public class Exercise
    {
        public string ExerciseName { get; set; }

        public string Description { get; set; }

        public string Instructions { get; set; }
    }
}
