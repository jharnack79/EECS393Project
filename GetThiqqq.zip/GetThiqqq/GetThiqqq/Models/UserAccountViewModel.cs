﻿using System;

namespace GetThiqqq.Models
{
    public class UserAccountViewModel
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public string UserPassword { get; set; }

        public string UserEmail { get; set; }

    }
}
