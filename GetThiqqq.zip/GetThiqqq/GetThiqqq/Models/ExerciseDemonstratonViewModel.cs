﻿using System;
using System.Collections.Generic;
using System.Text;
using GetThiqqq.Services;

namespace GetThiqqq.Models
{
    public class ExerciseDemonstratonViewModel
    {
        public int UserAccountId { get; set; }

        public Exercise Exercise { get; set; }
    }
}
