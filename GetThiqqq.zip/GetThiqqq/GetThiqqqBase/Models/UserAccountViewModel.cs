﻿using System;

namespace GetThiqqqBase.Models
{
    public class UserAccountViewModel
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public string UserPassword { get; set; }

        public string UserEmail { get; set; }

    }
}
