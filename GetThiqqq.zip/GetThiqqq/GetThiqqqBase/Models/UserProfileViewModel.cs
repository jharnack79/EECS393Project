﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GetThiqqqBase.Models
{
    public class UserProfileViewModel
    {
        public int Id { get; set; }

        public int UserAccountId { get; set; }

        public string Address { get; set; }
    }
}
